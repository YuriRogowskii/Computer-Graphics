extends CharacterBody2D

class_name  pushables
const PUSH_SPEED = 300.0


# Get the gravity from the project settings to be synced with RigidBody nodes.
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")


func _physics_process(delta):
	# Add the gravity.
	if not is_on_floor():
		velocity.y += gravity * delta

	move_and_slide()

	velocity.x = 0
	
func slide_object(direction):
	velocity.x = int(direction.x) * PUSH_SPEED
