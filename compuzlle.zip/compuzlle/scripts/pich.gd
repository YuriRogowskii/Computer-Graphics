extends Area2D

@onready var pich = $"."
@onready var collision = $"../Door/collision2"
@onready var _01 = $"01"
@onready var label = $Label
@onready var animdoor = $"../Door/anim"

func _on_body_entered(body):
	pich.queue_free()
	_01.visible = false
	label.visible = false
	collision.set_deferred("disabled", false) 
	animdoor.play("open")
	
