extends StaticBody2D

@onready var anim = $anim
@onready var collision = $"../Door/collision2"
@onready var animdoor = $"../Door/anim"


func _on_button_collider_body_entered(body):
	if body.name != "player" and collision:
		anim.play("pressed")
		collision.set_deferred("disabled", false) 
		animdoor.play("open")

func _on_button_collider_body_exited(body):
	if body.name != "player" and collision:
		anim.play("no")
