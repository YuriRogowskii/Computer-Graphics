extends CharacterBody2D

@onready var anim = $anim

const SPEED = 200.0
@export var JUMP_VELOCITY = -450.0
var is_jump = false
var direction 

@export var gravity = 980


func _physics_process(delta):
	# Add the gravity.
	if not is_on_floor():
		velocity.y += gravity * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		is_jump = true
		velocity.y = JUMP_VELOCITY
	elif is_on_floor():
		is_jump = false

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	direction = Input.get_axis("ui_left", "ui_right")
	if direction!=0 :
		velocity.x = direction * SPEED
		anim.scale.x = direction
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		

	move_and_slide()
	apply_push_force()
	_set_state()

func _set_state():
	var state = "idle"
	if !is_on_floor():
		state = "jump"
	elif direction !=0:
		state = "run"
	if anim.name != state:
		anim.play(state)

func apply_push_force():
	for object in get_slide_collision_count():
		var collision = get_slide_collision(object)
		if collision.get_collider() is pushables:
			collision.get_collider().slide_object(-collision.get_normal())
